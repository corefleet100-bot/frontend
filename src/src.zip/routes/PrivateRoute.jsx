const PrivateRoute = ({ children }) => {
    // No actual validation for now
    return children;
};

export default PrivateRoute;
  