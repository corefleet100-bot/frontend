import React from 'react'

const Shipping = () => {
  return (
    <div>Shipping</div>
  )
}

export default Shipping