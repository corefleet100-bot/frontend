import React from 'react'

const Quote = () => {
  return (
    <div>Quote</div>
  )
}

export default Quote