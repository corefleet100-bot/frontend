import React from 'react'

const Fulfillment = () => {
  return (
    <div>Fulfillment</div>
  )
}

export default Fulfillment